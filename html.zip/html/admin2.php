<?php

include('db/database.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>

    <link rel="stylesheet" href="css/admin2.css">

</head>

<body>

    <div id="heading">
        <h2>Login Credentials of Users:</h2>
        <h3>Admin Panel</h3>
    </div>

    <table border="0" id="tab">

        <tr align="center">
            <th width="150" height="50">Id</th>
            <th width="150">Username</th>
            <th width="150">Password</th>
            <th width="150">Email</th>
            <th width="150">Phone-Number</th>
            <th width="150">Reg-Date&Time</th>
        </tr>


        <?php

        $sql = "SELECT * FROM users";
        $result = mysqli_query($conn, $sql);

        while ($row = mysqli_fetch_assoc($result)) {

            echo "<tr align='center'>
            <td height='30'>" . $row['id'] . "</td>
            <td height='30'>" . $row['username'] . "</td>
            <td height='30'>" . $row['password'] . "</td>
            <td height='30'>" . $row['email'] . "</td>
            <td height='30'>" . $row['phnum'] . "</td>
            <td height='30'>" . $row['reg_date'] . "</td>
            </tr>";
        }

        mysqli_close($conn);

        ?>

    </table>

</body>

</html>